// Application Main Config
module.exports = {
  discord: {
    rain_id: "1112928389511254027",
    trivia_id: "",
    notificationWebhook: "https://discord.com/api/webhooks/1112926282938843178/M2v96uKRQvshZxr6vK_D_8R98ZvyjRynau7PxOfczxy0FMIlv8X2zHJDBlOIR7k0h1bL",
  },
  site: {
    // Site configurations on server startup
    enableMaintenanceOnStart: false,
    manualWithdrawsEnabled: true,
    enableLoginOnStart: true,
    // Site endpoints
    backend: {
      productionUrl: "https://api.moonbet.vip",
      developmentUrl: "http://localhost:5000",
    },
    frontend: {
      productionUrl: "https://moonbet.vip",
      developmentUrl: "http://localhost:3000",
    },
    adminFrontend: {
      productionUrl: "https://admin.moonbet.vip",
      developmentUrl: "http://localhost:8080",
    },
  },
  database: {
    developmentMongoURI: "mongodb+srv://deoparadox:adEJ7TWDQxdKc58D@cluster0.iwnrfpv.mongodb.net/?retryWrites=true&w=majority", // MongoURI to use in development
    productionMongoURI: "mongodb+srv://deoparadox:adEJ7TWDQxdKc58D@cluster0.iwnrfpv.mongodb.net/?retryWrites=true&w=majority", // MongoURI to use in production
  },
  // Each specific game configuration
  games: {
    exampleGame: {
      minBetAmount: 1, // Min bet amount (in coins)
      maxBetAmount: 100000, // Max bet amount (in coins)
      feePercentage: 0.1, // House fee percentage
    },
    race: {
      prizeDistribution: [40, 20, 14.5, 7, 5.5, 4.5, 3.5, 2.5, 1.5, 1], // How is the prize distributed (place = index + 1)
    },
    vip: {
      levels: [
        {
          name: "Iron",
          wagerNeeded: 0,
          rakebackPercentage: 2.5,
        },
        {
          name: "Bronze",
          wagerNeeded: 35000,
          rakebackPercentage: 3,
        },
        {
          name: "Silver",
          wagerNeeded: 100000,
          rakebackPercentage: 4,
        },
        {
          name: "Gold",
          wagerNeeded: 250000,
          rakebackPercentage: 6.5,
        },
        {
          name: "Platinum",
          wagerNeeded: 500000,
          rakebackPercentage: 8,
        },
        {
          name: "Diamond",
          wagerNeeded: 1000000,
          rakebackPercentage: 10,
        },
      ],
    },
    affiliates: {
      earningPercentage: 5, // How many percentage of house edge the affiliator will get
    },
    cups: {
      minBetAmount: 0.1, // Min bet amount (in coins)
      maxBetAmount: 100000, // Max bet amount (in coins)
      feePercentage: 0.05, // House fee percentage
    },
    king: {
      minBetAmount: 0.1, // Min bet amount (in coins)
      maxBetAmount: 100000, // Max bet amount (in coins)
      feePercentage: 0.05, // House fee percentage
      autoChooseTimeout: 30000, // Auto-choser timeout in ms
    },
    shuffle: {
      minBetAmount: 0.1, // Min bet amount (in coins)
      maxBetAmount: 100000, // Max bet amount (in coins)
      feePercentage: 0.05, // House fee percentage
      waitingTime: 30000,
    },
    roulette: {
      minBetAmount: 0.1, // Min bet amount (in coins)
      maxBetAmount: 1000, // Max bet amount (in coins)
      feePercentage: 0.04, // House fee percentage
      waitingTime: 30000, // Roulette waiting time in ms
    },
    crash: {
      minBetAmount: 0.1, // Min bet amount (in coins)
      maxBetAmount: 1000, // Max bet amount (in coins)
      maxProfit: 1000, // Max profit on crash, forces auto cashout
      houseEdge: 0.15, // House edge percentage
    },
    slots: {
      maxProfit: 1000, 
      houseEdge: 0.02, // House edge percentage
    },
    battles: {
      maxProfit: 1000, 
      houseEdge: 0.075, // House edge percentage
    }
  },
  blochain: {
    // EOS Blockchain provider API root url
    // without following slashes
    httpProviderApi: "http://eos.greymass.com",
  },
  authentication: {
    jwtSecret: "SECRETKEYNOONEELSECANKNOW", // Secret used to sign JWT's. KEEP THIS AS A SECRET
    jwtExpirationTime: 360000, // JWT-token expiration time (in seconds)
    apirone: {
      account_id: "apr-26230e5ac31a1bc84d13d31255b37a5f",
      transfer_key: "57yxp2Hrm7OBAQM7BIcHrUXIh4K34qzO",
      base_url: "https://apirone.com/api",
      callback_url: "https://api.moonbet.vip/api/deposit",
      callback_sercret: "nj3jn319dfnknlmskls099l1oppds0912312"
    },
    caleta: {
      operator: {
        operator_id: "moonbet",
      },
      caleta: {
        base_url: "https://asianapi.the-rgs.com/api",
      },
    },
    bgaming: {
      GCP_URL: "https://int.bgaming-system.com/a8r/moonbetvip-int",
      CASINO_ID: "moonbetvip-int",
      AUTH_TOKEN: "wW6LkL64uhhkxnHyauZCkjA2",
    },
    twilio: {
      accountSid: "ACc02d3f0db05b2af7431202ed84cc1986",
      authToken: "8eb9c03c730671808a1b76a73459a6ae",
      verifyServiceSid: "VA955df75850f48b4cbb09e94ee7b617b4",
    },
    reCaptcha: {
      secretKey: "6LewsU4mAAAAAPQzQf81LmaQjscRI4b04bAEfGqQ", // production-secret: 6LeovFwmAAAAAFBNTmcMJwS4VyOp_PNXV6Q0dc_C
    },
    googleOauth: {
      clientId: "943326792202-a710mljsekgud4hqi16tgt6jbo2f3dmc.apps.googleusercontent.com",
      clientSecret: "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",
    },
    steam: {
      apiKey: "861C644CBDC89D3F5FF8DB8F98CC2ED6", // Your Steam API key
    },
  },
};
